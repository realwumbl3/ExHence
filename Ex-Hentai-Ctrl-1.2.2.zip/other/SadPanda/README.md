# SadPanda

Chromium extension to access E-hentai

## Usage

* Clone this repository or download the ZIP and extract it
* Navigate to `chrome://extensions`
* Toggle the `Developer Mode` slider in the top right corner
* Click on `Load Unpacked` and navigate to the folder where you have the extension
* Navigate to <https://exhentai.org/>
* Log in and enjoy!
